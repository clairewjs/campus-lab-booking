CREATE TABLE `bookings` (
	`id` text PRIMARY KEY NOT NULL,
	`lab` text NOT NULL,
	`date` text NOT NULL,
	`start` text NOT NULL,
	`end` text NOT NULL,
	`title` text NOT NULL,
	`kind` text NOT NULL,
	`status` text NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`program` text NOT NULL,
	`supplies` text NOT NULL,
	`companions` integer NOT NULL,
	`created` text NOT NULL
);
