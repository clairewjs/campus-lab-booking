import { build } from 'esbuild';
import { mkdir,writeFile,copyFile } from 'node:fs/promises';
await mkdir('docs',{recursive:true});
await build({stdin:{contents:"import React from 'react';import {createRoot} from 'react-dom/client';import Page from './app/page';createRoot(document.getElementById('root')).render(<Page/>);",resolveDir:process.cwd(),sourcefile:'pages-entry.tsx',loader:'tsx'},outfile:'docs/app.js',bundle:true,minify:true,jsx:'automatic',platform:'browser',target:'es2022',define:{'process.env.NODE_ENV':'"production"','process.env.NEXT_PUBLIC_GITHUB_PAGES':'"true"'},legalComments:'linked'});
await copyFile('app/globals.css','docs/style.css');
await writeFile('docs/.nojekyll','');
await writeFile('docs/index.html','<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Find available Big Lab and Small Lab times and request a practice session."><title>LabSpace | Campus Lab Booking</title><link rel="stylesheet" href="./style.css"></head><body><div id="root"></div><script defer src="./app.js"></script></body></html>');
console.log('GitHub Pages files built in docs/');
